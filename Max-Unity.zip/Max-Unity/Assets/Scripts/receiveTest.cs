﻿using UnityEngine;
using System.Collections;

using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class receiveTest : MonoBehaviour
{

    // receiving Thread
    Thread receiveThread;

    // udpclient object
    UdpClient client;

    // public
    // public string IP = "127.0.0.1"; default local
    public int port; // define > init
    public string function = "Node Sizes";

    // infos
    private string lastReceivedUDPPacket = "";
    private string[] UDPString = new string[65];
    public float[] udpReceive = new float[65]; // received string is 64 elements long but only first 45 from fft~ are used

    private Vector3[] currentScale = new Vector3[45];
    private Vector3[] targetScale = new Vector3[45];

    float lerpTime = 150f;
    float currentLerpTime = 0f;

    //public GameObject myScore;


    // start from shell
    private static void Main()
    {
        receiveTest receiveObj = new receiveTest();
        receiveObj.init();

        string text = "";
        do
        {
            text = Console.ReadLine();
        }
        while (!text.Equals("exit"));
    }

    public void Start()
    {
        init();
    }


    public void Update()
    {
//        scaleNodes();
    }


    private void init()
    {
        // define port
        port = 7401;

        receiveThread = new Thread(
            new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }

    // receive thread
    private void ReceiveData()
    {
        client = new UdpClient(port);
        while (true)
        {
            try
            {
                IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, 0);
                byte[] data = client.Receive(ref anyIP);

                string text = Encoding.UTF8.GetString(data);

                lastReceivedUDPPacket = text;
                UDPString = lastReceivedUDPPacket.Split(' ');
                Debug.Log(UDPString);
                currentLerpTime = 0f;
                parseUDP();
            }

            catch (Exception err)
            {
                print(err.ToString());
            }
        }
    }

    public string getLatestUDPPacket()
    {
        return lastReceivedUDPPacket;
    }


    public void parseUDP() //
    {
        for (int i = 0; i < 65; i++) // seed udpReceive
        {
            udpReceive[i] = float.Parse(UDPString[i]); //
        }
    }

//    public void scaleNodes()
//    {
//        for (int i = 0; i < 45; i++)
//        {
//            currentScale[i] = myScore.transform.GetChild(i).GetComponentInChildren<Transform>().localScale;
//            targetScale[i] = new Vector3(udpReceive[i] * .75f, udpReceive[i] * .75f, udpReceive[i]) * .75f;

//            currentLerpTime += Time.deltaTime;

//            if (currentLerpTime > lerpTime)
//            {
//                currentLerpTime = lerpTime;
//            }

//            float perc = currentLerpTime / lerpTime;
//            myScore.transform.GetChild(i).GetComponentInChildren<Transform>().localScale = Vector3.Lerp(currentScale[i], targetScale[i], perc);
//        }
//    }

}


