﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;

public class TCPTestServer : MonoBehaviour
{
    public int portNo;
    public int maxObjects;
    public GameObject Scripts;
    public string clientMessage;

    //public InstantiateSpheres InstantiateScript;

    public Boolean YouveGotMail;

    #region private members 	
    /// <summary> 	
    /// TCPListener to listen for incomming TCP connection 	
    /// requests. 	
    /// </summary> 	
    private TcpListener tcpListener;
    /// <summary> 
    /// Background thread for TcpServer workload. 	
    /// </summary> 	
    private Thread tcpListenerThread;
    /// <summary> 	
    /// Create handle to connected tcp client. 	
    /// </summary> 	
    private TcpClient connectedTcpClient;
    #endregion

    // Use this for initialization
    void Start()
    {
        Scripts = GameObject.FindGameObjectWithTag("Scripts");
        //InstantiateScript = Scripts.GetComponent<InstantiateSpheres>();
 
        //// Start TcpServer background thread 		
        tcpListenerThread = new Thread(new ThreadStart(ListenForIncommingRequests));
        tcpListenerThread.IsBackground = true;
        tcpListenerThread.Start();
        InvokeRepeating("SetScore", 0.00002f, 0.00002f);
    }

    // Update message
    void SetScore()
    {
        if (YouveGotMail == true)
        {
            Parse(clientMessage);
        }

    }

    /// <summary> 	
    /// Runs in background TcpServerThread; Handles incomming TcpClient requests 	
    /// </summary> 	
    private void ListenForIncommingRequests()
    {
        try
        {
            // Create listener on localhost port 8052. 			
            tcpListener = new TcpListener(IPAddress.Parse("192.168.20.12"), 7778);
            tcpListener.Start();
            Debug.Log("Server is listening");
            Byte[] bytes = new Byte[131072];
            while (true)
            {
                using (connectedTcpClient = tcpListener.AcceptTcpClient())
                {
                    // Get a stream object for reading 					
                    using (NetworkStream stream = connectedTcpClient.GetStream())
                    {
                        int length;
                        // Read incomming stream into byte arrary. 						
                        while ((length = stream.Read(bytes, 0, bytes.Length)) != 0)
                        {
                            var incommingData = new byte[length];
                            Array.Copy(bytes, 0, incommingData, 0, length);
                            // Convert byte array to string message. 							
                            clientMessage = Encoding.ASCII.GetString(incommingData);
                            Debug.Log("client message received as: " + clientMessage);
                            YouveGotMail = true;
                        }
                    }
                }
            }
        }
        catch (SocketException socketException)
        {
            Debug.Log("SocketException " + socketException.ToString());
        }
    }

    void Parse(string toParse)
    {
        //split up message 
        string[] clientMessage = toParse.Split(' ');
        // pNum = int.Parse(values[3]);
        Debug.Log(clientMessage[0]);

        if (clientMessage[0] == "1")
        {
        //     // set node and line names

        //     InstantiateScript.nI = InstantiateScript.nI++;
            
        //     //set node colour
        
        //     // nCR = float.Parse(clientMessage[10]);
        //     // nCG = float.Parse(clientMessage[11]);
        //     // nCB = float.Parse(clientMessage[12]);
        //     // nCA = float.Parse(clientMessage[13]);

        //     // set start and end points of lines, set node points
        //     InstantiateScript.nx = float.Parse(clientMessage[1]);
        //     InstantiateScript.ny = float.Parse(clientMessage[2]);
        //     InstantiateScript.nz = float.Parse(clientMessage[3]);
        //     InstantiateScript.xx = float.Parse(clientMessage[4]);
        //     InstantiateScript.xy = float.Parse(clientMessage[5]);
        //     InstantiateScript.xz = float.Parse(clientMessage[6]);
        //     InstantiateScript.zx = float.Parse(clientMessage[7]);
        //     InstantiateScript.zy = float.Parse(clientMessage[8]);
        //     InstantiateScript.zz = float.Parse(clientMessage[9]);

        //     //Instantiate node and lines
        //     InstantiateScript.InstantiateNodes();
        //     // InstantiateScript.nodeColour = new Color(nCR, nCG, nCB, nCA);

            //reset for new message
            YouveGotMail = false;
        }

    }
    private void SendMessage()
    {
        if (connectedTcpClient == null)
        {
            return;
        }

        try
        {
            // Get a stream object for writing. 			
            NetworkStream stream = connectedTcpClient.GetStream();
            if (stream.CanWrite)
            {
                string serverMessage = "This is a message from your server.";
                // Convert string message to byte array.                 
                byte[] serverMessageAsByteArray = Encoding.ASCII.GetBytes(serverMessage);
                // Write byte array to socketConnection stream.               
                stream.Write(serverMessageAsByteArray, 0, serverMessageAsByteArray.Length);
                Debug.Log("Server sent his message - should be received by client");
            }
        }
        catch (SocketException socketException)
        {
            Debug.Log("Socket exception: " + socketException);
        }
    }
}